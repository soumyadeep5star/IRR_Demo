import sys
import time
from src.config import load_config
from src.vector_store import VectorStore
from src.embedder import EmbeddingManager
from src.pipeline import IncidentPipeline

def show_usage():
    print("""
Usage:
    python main.py ingest <knowledge_folder>   Build local FAISS vector store
    python main.py run-once                    Execute a single polling & resolution run
    python main.py poll                        Start continuous background polling loop
""")

def main():
    if len(sys.argv) < 2:
        show_usage()
        sys.exit(1)

    cmd = sys.argv[1].lower()
    config = load_config()

    if cmd == "ingest":
        folder = sys.argv[2] if len(sys.argv) > 2 else "knowledge"
        embedder = EmbeddingManager(config.embedding_model_name, config.max_embedding_tokens)
        store = VectorStore(embedder)
        store.build_from_directory(folder)
    elif cmd == "run-once":
        pipeline = IncidentPipeline(config)
        pipeline.run_poll_cycle()
    elif cmd == "poll":
        pipeline = IncidentPipeline(config)
        print(f"Starting continuous polling every {config.poll_interval_seconds}s (Ctrl+C to stop)...")
        while True:
            try:
                pipeline.run_poll_cycle()
            except KeyboardInterrupt:
                print("\nPoller stopped by user.")
                break
            except Exception as e:
                print(f"[UNHANDLED EXCEPTION in poll loop]: {e}")
            time.sleep(config.poll_interval_seconds)
    else:
        show_usage()
        sys.exit(1)

if __name__ == "__main__":
    main()