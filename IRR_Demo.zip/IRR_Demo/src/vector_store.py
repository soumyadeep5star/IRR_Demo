import os
import json
import faiss
import numpy as np
from dataclasses import dataclass, asdict
from pypdf import PdfReader
from src.embedder import EmbeddingManager

INDEX_FILE = "faiss_index.bin"
METADATA_FILE = "faiss_metadata.json"

@dataclass
class DocumentMetadata:
    doc_id: str
    source_filename: str
    title: str
    full_text: str
    doc_type: str
    token_count: int

class VectorStore:
    def __init__(self, embedding_manager: EmbeddingManager):
        self.embedder = embedding_manager
        self.index: faiss.IndexFlatIP | None = None
        self.metadata: list[DocumentMetadata] = []

    def build_from_directory(self, knowledge_dir: str) -> None:
        if not os.path.isdir(knowledge_dir):
            raise FileNotFoundError(f"Knowledge directory '{knowledge_dir}' does not exist.")

        files = sorted(os.listdir(knowledge_dir))
        docs: list[DocumentMetadata] = []

        for fname in files:
            fpath = os.path.join(knowledge_dir, fname)
            if not os.path.isfile(fpath):
                continue

            ext = os.path.splitext(fname)[1].lower()
            text = ""
            doc_type = "UNKNOWN"

            if ext in [".txt", ".md"]:
                doc_type = "SOP" if "sop" in fname.lower() else "KB"
                with open(fpath, "r", encoding="utf-8", errors="replace") as f:
                    text = f.read().strip()
            elif ext == ".pdf":
                doc_type = "PDF_DOC"
                reader = PdfReader(fpath)
                pages = [page.extract_text() or "" for page in reader.pages]
                text = "\n".join(pages).strip()
            else:
                continue

            if not text:
                print(f"[INGESTION] Skipping empty or unextractable document: {fname}")
                continue

            doc_id = os.path.splitext(fname)[0]
            token_count = self.embedder.validate_token_limit(text, fname)
            title = text.splitlines()[0][:120].strip("# \t") or doc_id

            docs.append(DocumentMetadata(
                doc_id=doc_id,
                source_filename=fname,
                title=title,
                full_text=text,
                doc_type=doc_type,
                token_count=token_count
            ))

        if not docs:
            raise RuntimeError(f"No valid documents found in '{knowledge_dir}' to ingest.")

        texts = [d.full_text for d in docs]
        vectors = self.embedder.embed_normalized(texts)
        dimension = vectors.shape[1]

        index = faiss.IndexFlatIP(dimension)
        index.add(vectors)

        faiss.write_index(index, INDEX_FILE)
        meta_payload = {
            "model_name": self.embedder.model_name,
            "dimension": dimension,
            "documents": [asdict(d) for d in docs]
        }
        with open(METADATA_FILE, "w", encoding="utf-8") as f:
            json.dump(meta_payload, f, indent=2)

        self.index = index
        self.metadata = docs
        print(f"[INGESTION] Successfully indexed {len(docs)} documents (1 document = 1 chunk).")

    def load(self) -> None:
        if not os.path.exists(INDEX_FILE) or not os.path.exists(METADATA_FILE):
            raise FileNotFoundError("FAISS index or metadata missing. Run knowledge ingestion first.")

        with open(METADATA_FILE, "r", encoding="utf-8") as f:
            meta_payload = json.load(f)

        if meta_payload.get("model_name") != self.embedder.model_name:
            raise ValueError(
                f"Model mismatch! Index was created with '{meta_payload.get('model_name')}', "
                f"but runtime is configured for '{self.embedder.model_name}'."
            )

        self.index = faiss.read_index(INDEX_FILE)
        self.metadata = [DocumentMetadata(**item) for item in meta_payload["documents"]]

    def search(self, query_text: str, top_k: int, min_similarity: float) -> list[tuple[DocumentMetadata, float]]:
        if self.index is None:
            self.load()

        self.embedder.validate_token_limit(query_text, "Incident Query")
        query_vec = self.embedder.embed_normalized([query_text])
        scores, indices = self.index.search(query_vec, min(top_k, len(self.metadata)))

        results = []
        for idx, score in zip(indices[0], scores[0]):
            if idx == -1:
                continue
            if score >= min_similarity:
                results.append((self.metadata[idx], float(score)))
        return results