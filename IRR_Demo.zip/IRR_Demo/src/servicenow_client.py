import time
from typing import Any, Optional
import requests
from requests.auth import HTTPBasicAuth
from src.config import AppConfig

class ServiceNowClient:
    def __init__(self, config: AppConfig):
        self.config = config
        self.base_url = config.sn_instance_url
        self.auth = HTTPBasicAuth(config.sn_username, config.sn_password)
        self.headers = {"Accept": "application/json", "Content-Type": "application/json"}
        self._group_cache: dict[str, str] = {}

    def _execute_request(self, method: str, url: str, **kwargs) -> requests.Response:
        retries = self.config.max_retries
        backoff = self.config.retry_base_backoff_seconds
        kwargs.setdefault("timeout", self.config.request_timeout_seconds)
        kwargs.setdefault("verify", True)
        kwargs.setdefault("auth", self.auth)
        kwargs.setdefault("headers", self.headers)

        for attempt in range(1, retries + 1):
            try:
                res = requests.request(method, url, **kwargs)
                if res.status_code in (401, 403):
                    raise PermissionError(f"ServiceNow Authentication failed ({res.status_code}): Check credentials.")
                if res.status_code == 429 or 500 <= res.status_code < 600:
                    if attempt == retries:
                        res.raise_for_status()
                    time.sleep(backoff)
                    backoff *= 2
                    continue
                res.raise_for_status()
                return res
            except (requests.ConnectionError, requests.Timeout) as e:
                if attempt == retries:
                    raise RuntimeError(f"ServiceNow connection failed after {retries} attempts: {e}")
                time.sleep(backoff)
                backoff *= 2

        raise RuntimeError(f"ServiceNow request failed unexpectedly.")

    def resolve_group_sys_id(self, group_name: str) -> str:
        if group_name in self._group_cache:
            return self._group_cache[group_name]

        url = f"{self.base_url}/api/now/table/sys_user_group"
        params = {"sysparm_query": f"name={group_name}", "sysparm_limit": "1", "sysparm_fields": "sys_id,name"}
        resp = self._execute_request("GET", url, params=params).json()
        results = resp.get("result", [])
        if not results:
            raise ValueError(f"Assignment Group '{group_name}' not found in ServiceNow.")
        
        sys_id = results[0]["sys_id"]
        self._group_cache[group_name] = sys_id
        return sys_id

    def get_incidents_page(self, group_sys_ids: list[str], state: str, updated_after: Optional[str],
                           offset: int, limit: int) -> list[dict[str, Any]]:
        query_parts = [
            f"state={state}",
            f"assignment_groupIN{','.join(group_sys_ids)}"
        ]
        if updated_after:
            query_parts.append(f"sys_updated_on>={updated_after}")

        params = {
            "sysparm_query": "^".join(query_parts) + "^ORDERBYsys_updated_on",
            "sysparm_limit": str(limit),
            "sysparm_offset": str(offset),
            "sysparm_fields": "sys_id,number,short_description,description,state,assignment_group,sys_updated_on"
        }
        url = f"{self.base_url}/api/now/table/incident"
        resp = self._execute_request("GET", url, params=params).json()
        return resp.get("result", [])

    def fetch_single_incident(self, sys_id: str) -> dict[str, Any]:
        url = f"{self.base_url}/api/now/table/incident/{sys_id}"
        params = {"sysparm_fields": "sys_id,number,short_description,description,state,assignment_group,sys_updated_on"}
        resp = self._execute_request("GET", url, params=params).json()
        return resp.get("result", {})

    def post_work_notes(self, sys_id: str, work_notes: str) -> bool:
        url = f"{self.base_url}/api/now/table/incident/{sys_id}"
        payload = {"work_notes": work_notes}
        res = self._execute_request("PATCH", url, json=payload)
        return res.status_code == 200