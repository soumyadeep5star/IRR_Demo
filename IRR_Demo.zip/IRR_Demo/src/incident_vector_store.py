import os
import json
import faiss
import numpy as np
from dataclasses import dataclass, asdict
from src.embedder import EmbeddingManager

INCIDENT_INDEX_FILE = "incident_faiss_index.bin"
INCIDENT_METADATA_FILE = "incident_faiss_metadata.json"

@dataclass
class HistoricalIncidentMetadata:
    doc_id: str  # Incident Number (e.g., INC0012345)
    sys_id: str
    number: str
    category: str
    subcategory: str
    assignment_group: str
    short_description: str
    description: str
    close_code: str
    close_notes: str
    full_text: str
    token_count: int

class IncidentVectorStore:
    def __init__(self, embedding_manager: EmbeddingManager):
        self.embedder = embedding_manager
        self.index: faiss.IndexFlatIP | None = None
        self.metadata: list[HistoricalIncidentMetadata] = []

    def build_from_records(self, records: list[dict]) -> None:
        valid_items: list[HistoricalIncidentMetadata] = []
        texts_to_embed: list[str] = []

        for r in records:
            # Construct text payload skipping empty/missing values
            parts = []
            if r.get("number"):
                parts.append(f"Incident Number: {r['number']}")
            if r.get("category"):
                parts.append(f"Category: {r['category']}")
            if r.get("subcategory"):
                parts.append(f"Subcategory: {r['subcategory']}")
            if r.get("assignment_group"):
                parts.append(f"Assignment Group: {r['assignment_group']}")
            if r.get("short_description"):
                parts.append(f"Short Description: {r['short_description']}")
            if r.get("description"):
                parts.append(f"Description: {r['description']}")
            if r.get("work_notes"):
                parts.append(f"Work Notes:\n{r['work_notes']}")
            if r.get("close_code"):
                parts.append(f"Close Code: {r['close_code']}")
            if r.get("close_notes"):
                parts.append(f"Close Notes:\n{r['close_notes']}")

            content = "\n".join(parts).strip()
            if not content:
                continue

            doc_id = r.get("number") or r.get("sys_id")
            token_count = self.embedder.count_tokens(content)

            # Strictly enforce token limits (no truncation)
            if token_count > self.embedder.max_tokens:
                print(f"[INGESTION] Skipping incident {doc_id}: {token_count} tokens exceeds {self.embedder.max_tokens} limit.")
                continue

            item = HistoricalIncidentMetadata(
                doc_id=doc_id,
                sys_id=r.get("sys_id", ""),
                number=r.get("number", ""),
                category=r.get("category", ""),
                subcategory=r.get("subcategory", ""),
                assignment_group=r.get("assignment_group", ""),
                short_description=r.get("short_description", ""),
                description=r.get("description", ""),
                close_code=r.get("close_code", ""),
                close_notes=r.get("close_notes", ""),
                full_text=content,
                token_count=token_count
            )
            valid_items.append(item)
            texts_to_embed.append(content)

        if not valid_items:
            raise RuntimeError("No eligible incidents with content found to index.")

        print(f"[INGESTION] Embedding {len(texts_to_embed)} historical incidents...")
        vectors = self.embedder.embed_normalized(texts_to_embed)
        dim = vectors.shape[1]

        index = faiss.IndexFlatIP(dim)
        index.add(vectors)

        faiss.write_index(index, INCIDENT_INDEX_FILE)
        meta_payload = {
            "model_name": self.embedder.model_name,
            "dimension": dim,
            "documents": [asdict(x) for x in valid_items]
        }
        with open(INCIDENT_METADATA_FILE, "w", encoding="utf-8") as f:
            json.dump(meta_payload, f, indent=2)

        self.index = index
        self.metadata = valid_items
        print(f"[INGESTION] Successfully created incident index with {len(valid_items)} records.")

    def load(self) -> None:
        if not os.path.exists(INCIDENT_INDEX_FILE) or not os.path.exists(INCIDENT_METADATA_FILE):
            raise FileNotFoundError("Incident FAISS index or metadata missing. Run incident ingestion first.")

        with open(INCIDENT_METADATA_FILE, "r", encoding="utf-8") as f:
            payload = json.load(f)

        if payload.get("model_name") != self.embedder.model_name:
            raise ValueError(f"Model mismatch in incident index: expected {self.embedder.model_name}, found {payload.get('model_name')}")

        self.index = faiss.read_index(INCIDENT_INDEX_FILE)
        self.metadata = [HistoricalIncidentMetadata(**item) for item in payload["documents"]]

    def search(self, query_text: str, top_k: int, min_similarity: float = 0.0) -> list[tuple[HistoricalIncidentMetadata, float]]:
        if self.index is None:
            self.load()

        self.embedder.validate_token_limit(query_text, "Incident Query")
        query_vec = self.embedder.embed_normalized([query_text])
        scores, indices = self.index.search(query_vec, min(top_k, len(self.metadata)))

        results = []
        for idx, score in zip(indices[0], scores[0]):
            if idx == -1:
                continue
            if score >= min_similarity:
                results.append((self.metadata[idx], float(score)))
        return results