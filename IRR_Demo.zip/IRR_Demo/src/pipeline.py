import os
import time
from datetime import datetime, timezone, timedelta
from typing import Any
from src.config import AppConfig
from src.storage import load_responses, save_responses, get_watermark, save_watermark
from src.embedder import EmbeddingManager
from src.vector_store import VectorStore
from src.incident_vector_store import IncidentVectorStore
from src.servicenow_client import ServiceNowClient
from src.llm_agent import ResolutionGenerator

# Explicit requirement: Primary KB match threshold
KB_SIMILARITY_THRESHOLD = 0.70

class IncidentPipeline:
    def __init__(self, config: AppConfig):
        self.config = config
        self.sn_client = ServiceNowClient(config)
        self.embedder = EmbeddingManager(config.embedding_model_name, config.max_embedding_tokens)
        self.kb_vector_store = VectorStore(self.embedder)
        self.incident_vector_store = IncidentVectorStore(self.embedder)
        self.generator = ResolutionGenerator(config)

    def run_poll_cycle(self) -> None:
        self.kb_vector_store.load()

        # Conditionally load historical incidents index if it exists on disk
        if os.path.exists("incident_faiss_index.bin") and os.path.exists("incident_faiss_metadata.json"):
            self.incident_vector_store.load()
        else:
            print("[WARN] incident_faiss_index.bin not found. Run python ingest_incidents.py to build it.")

        responses = load_responses()
        
        # Resolve group names to sys_ids
        group_ids = [self.sn_client.resolve_group_sys_id(g) for g in self.config.sn_assignment_groups]

        # Retry eligible previously pending/failed records
        self._retry_pending_and_failed(responses, group_ids)

        # Calculate time cutoff with configured overlap
        last_watermark = get_watermark()
        new_cutoff = datetime.now(timezone.utc).isoformat()
        filter_time = None
        if last_watermark:
            dt = datetime.fromisoformat(last_watermark) - timedelta(seconds=self.config.poll_overlap_seconds)
            # Format expected by ServiceNow: YYYY-MM-DD HH:MM:SS
            filter_time = dt.strftime("%Y-%m-%d %H:%M:%S")

        # Deterministic pagination
        offset = 0
        all_pages_fetched_cleanly = True

        while True:
            try:
                page = self.sn_client.get_incidents_page(
                    group_sys_ids=group_ids,
                    state=self.config.sn_new_state,
                    updated_after=filter_time,
                    offset=offset,
                    limit=self.config.page_size
                )
            except Exception as e:
                print(f"[POLL ERROR] Failed fetching page at offset {offset}: {e}")
                all_pages_fetched_cleanly = False
                break

            if not page:
                break

            for incident in page:
                self._process_single_incident(incident, group_ids, responses)
                save_responses(responses)

            if len(page) < self.config.page_size:
                break
            offset += self.config.page_size

        if all_pages_fetched_cleanly:
            save_watermark(new_cutoff)
            print(f"[WATERMARK] Successfully advanced cutoff to {new_cutoff}")
        else:
            print("[WATERMARK] Incomplete poll cycle detected. Watermark held at previous state.")

    def _process_single_incident(self, incident: dict[str, Any], group_ids: list[str],
                                responses: dict[str, Any]) -> None:
        sys_id = incident["sys_id"]
        number = incident.get("number", sys_id)
        existing = responses.get(sys_id)

        # Skip successfully posted incidents across restarts
        if existing and existing.get("status") == "POSTED":
            return

        query_text = f"{incident.get('short_description', '')}\n{incident.get('description', '')}".strip()
        if not query_text:
            query_text = incident.get("short_description") or "Empty incident description"

        matched_docs = []
        source_type = "KB"

        # --- STEP 1: Search Primary KB Store (Threshold >= 0.70) ---
        try:
            kb_matches = self.kb_vector_store.search(
                query_text=query_text,
                top_k=self.config.top_k,
                min_similarity=KB_SIMILARITY_THRESHOLD
            )
        except Exception as e:
            print(f"[{number}] Error matching KB documents: {e}")
            kb_matches = []

        if kb_matches:
            matched_docs = [m[0] for m in kb_matches]
            source_type = "KB"
            print(f"[{number}] Matched {len(matched_docs)} KB article(s) >= {KB_SIMILARITY_THRESHOLD} similarity.")
        else:
            # --- STEP 2: Fallback to Historical Incident Store ---
            print(f"[{number}] No KB exceeded similarity {KB_SIMILARITY_THRESHOLD}. Checking historical incident store...")
            if self.incident_vector_store.index is not None:
                try:
                    inc_matches = self.incident_vector_store.search(
                        query_text=query_text,
                        top_k=self.config.top_k,
                        min_similarity=self.config.similarity_threshold
                    )
                    if inc_matches:
                        matched_docs = [m[0] for m in inc_matches]
                        source_type = "INCIDENT"
                        print(f"[{number}] Matched {len(matched_docs)} historical incident(s).")
                except Exception as e:
                    print(f"[{number}] Error matching historical incidents: {e}")

        # If neither repository provided relevant context
        if not matched_docs:
            responses[sys_id] = {
                "number": number,
                "status": "INSUFFICIENT_EVIDENCE",
                "reason": "Neither KB (>= 0.70) nor historical incident store yielded relevant matches.",
                "updated_at": datetime.now(timezone.utc).isoformat()
            }
            print(f"[{number}] Insufficient evidence found in both indexes. Recommendation omitted.")
            return

        fingerprint = self.generator.calculate_fingerprint(query_text, [d.doc_id for d in matched_docs])

        # If already generated as dry-run and input hasn't changed
        if existing and existing.get("fingerprint") == fingerprint and existing.get("status") == "DRY_RUN":
            if self.config.dry_run or not self.config.auto_post_saved_dry_runs:
                return
            rec = existing["recommendation"]
        else:
            rec = self.generator.generate_recommendation(incident, matched_docs, source_type=source_type)

        if rec.get("status") == "INSUFFICIENT_EVIDENCE":
            responses[sys_id] = {
                "number": number,
                "fingerprint": fingerprint,
                "status": "INSUFFICIENT_EVIDENCE",
                "recommendation": rec,
                "updated_at": datetime.now(timezone.utc).isoformat()
            }
            print(f"[{number}] Insufficient evidence/context. Recommendation omitted.")
            return

        # Prepare write-back or record dry-run
        if self.config.dry_run:
            responses[sys_id] = {
                "number": number,
                "fingerprint": fingerprint,
                "status": "DRY_RUN",
                "recommendation": rec,
                "source_type": source_type,
                "updated_at": datetime.now(timezone.utc).isoformat()
            }
            print(f"[{number}] [DRY-RUN - Source: {source_type}] Recommendation saved to JSON:\n"
                  f"{self.generator.format_work_note(rec)}\n")
            return

        # Write-back execution
        self._execute_write_back(incident, rec, fingerprint, responses)

    def _execute_write_back(self, incident: dict[str, Any], rec: dict[str, Any],
                            fingerprint: str, responses: dict[str, Any]) -> None:
        sys_id = incident["sys_id"]
        number = incident.get("number", sys_id)
        
        # Persist write intent before PATCH
        responses[sys_id] = {
            "number": number,
            "fingerprint": fingerprint,
            "status": "PENDING_WRITE",
            "recommendation": rec,
            "updated_at": datetime.now(timezone.utc).isoformat()
        }
        save_responses(responses)

        # Pre-patch verification: recheck current state & assignment group
        current = self.sn_client.fetch_single_incident(sys_id)
        current_state = str(current.get("state"))
        current_group = current.get("assignment_group", {})
        if isinstance(current_group, dict):
            current_group_id = current_group.get("value")
        else:
            current_group_id = str(current_group)

        valid_group_ids = [self.sn_client.resolve_group_sys_id(g) for g in self.config.sn_assignment_groups]
        if current_state != self.config.sn_new_state or current_group_id not in valid_group_ids:
            responses[sys_id]["status"] = "FAILED"
            responses[sys_id]["error"] = "Pre-patch safety failed: incident reassigned or state changed."
            return

        note_body = self.generator.format_work_note(rec)
        try:
            success = self.sn_client.post_work_notes(sys_id, note_body)
            if success:
                responses[sys_id]["status"] = "POSTED"
                print(f"[{number}] Successfully posted work note.")
            else:
                responses[sys_id]["status"] = "UNKNOWN_WRITE"
        except Exception as e:
            print(f"[{number}] Write-back failed with ambiguous status: {e}")
            responses[sys_id]["status"] = "UNKNOWN_WRITE"
            responses[sys_id]["error"] = str(e)

    def _retry_pending_and_failed(self, responses: dict[str, Any], group_ids: list[str]) -> None:
        for sys_id, item in list(responses.items()):
            if item.get("status") in ["FAILED", "PENDING_WRITE"]:
                retries = item.get("retry_count", 0)
                if retries >= self.config.max_retries:
                    continue
                try:
                    inc = self.sn_client.fetch_single_incident(sys_id)
                    if inc:
                        item["retry_count"] = retries + 1
                        self._process_single_incident(inc, group_ids, responses)
                except Exception as e:
                    item["error"] = f"Retry error: {e}"