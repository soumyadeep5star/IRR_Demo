import os
import json
import tempfile
from typing import Any, Optional

RESPONSES_FILE = "responses.json"
WATERMARK_FILE = ".last_poll_time"

def atomic_write_text(filepath: str, content: str) -> None:
    dirname = os.path.dirname(filepath) or "."
    with tempfile.NamedTemporaryFile("w", dir=dirname, delete=False, encoding="utf-8") as tf:
        tf.write(content)
        temp_name = tf.name
    os.replace(temp_name, filepath)

def load_responses() -> dict[str, Any]:
    if not os.path.exists(RESPONSES_FILE):
        return {}
    try:
        with open(RESPONSES_FILE, "r", encoding="utf-8") as f:
            return json.load(f)
    except Exception as e:
        raise RuntimeError(f"Corrupt state file detected: {RESPONSES_FILE}. Manual review required: {e}")

def save_responses(data: dict[str, Any]) -> None:
    atomic_write_text(RESPONSES_FILE, json.dumps(data, indent=2))

def get_watermark() -> Optional[str]:
    if not os.path.exists(WATERMARK_FILE):
        return None
    try:
        with open(WATERMARK_FILE, "r", encoding="utf-8") as f:
            val = f.read().strip()
            return val if val else None
    except Exception as e:
        raise RuntimeError(f"Corrupt watermark file detected: {WATERMARK_FILE}. Error: {e}")

def save_watermark(utc_iso_timestamp: str) -> None:
    atomic_write_text(WATERMARK_FILE, utc_iso_timestamp.strip())