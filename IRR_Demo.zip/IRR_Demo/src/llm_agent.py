import re
import json
import hashlib
from typing import Any
from openai import OpenAI
from src.config import AppConfig

class ResolutionGenerator:
    def __init__(self, config: AppConfig):
        self.config = config
        self.client = OpenAI(
            base_url=config.groq_base_url,
            api_key=config.groq_api_key
        )

    @staticmethod
    def calculate_fingerprint(incident_text: str, matched_doc_ids: list[str]) -> str:
        payload = f"{incident_text}|{','.join(sorted(matched_doc_ids))}"
        return hashlib.sha256(payload.encode("utf-8")).hexdigest()

    def generate_recommendation(self, incident: dict[str, Any],
                                matched_docs: list[Any],
                                source_type: str = "KB") -> dict[str, Any]:
        short_desc = incident.get("short_description") or ""
        desc = incident.get("description") or ""
        incident_body = f"Short Description: {short_desc}\nDescription: {desc}".strip()

        # Token context budget check (heuristic: 1 token ~= 4 chars)
        doc_contexts = []
        total_chars = len(incident_body)
        char_budget = (self.config.llm_context_budget_tokens - self.config.llm_output_reserved_tokens) * 4

        usable_docs = []
        for d in matched_docs:
            block = f"--- EVIDENCE ID: {d.doc_id} ---\n{d.full_text}\n"
            if total_chars + len(block) <= char_budget:
                doc_contexts.append(block)
                total_chars += len(block)
                usable_docs.append(d)
            else:
                break

        if not usable_docs:
            return {
                "status": "INSUFFICIENT_EVIDENCE",
                "reason": f"No usable {source_type} records fit within context budget.",
                "sources": []
            }

        valid_ids = {d.doc_id for d in usable_docs}

        evidence_label = "Knowledge Base Documents" if source_type == "KB" else "Past Resolved Incident Records"

        # Prompt enforcing inline citations strictly in 'resolutions'
        system_prompt = (
            f"You are an Incident Resolution AI Assistant. Analyze the untrusted incident details against "
            f"the provided verified {evidence_label}.\n\n"
            "STRICT CITATION AND FORMATTING RULES:\n"
            "1. Ground all steps strictly in the provided evidence documents.\n"
            "2. Root Cause: Provide a clear, thorough, and well-explained narrative detailing why and how the issue occurred based on the evidence. If the root cause is not definitively proven by the text, explicitly prefix it with 'HYPOTHESIS: ' followed by the detailed explanation.\n"
            "3. At the end of every individual item in 'resolutions', append the exact document/incident ID "
            "in brackets, e.g., 'Perform restart on adapter [DOC_ID]'.\n"
            "4. Do NOT include bracketed document IDs or references in 'diagnostic_steps' or 'possible_cause'. Keep them plain text.\n"
            "5. If a resolution step relies on multiple documents, cite all of them: '[DOC_ID_1][DOC_ID_2]'.\n"
            "6. Never invent IDs. Only cite IDs present in <VERIFIED_EVIDENCE>.\n"
            "7. If an underlying cause is not definitively proven by the text, label it as 'HYPOTHESIS: ...'.\n"
            "8. Output valid, raw JSON only matching this schema:\n"
            "{\n"
            '  "problem_summary": "string",\n'
            '  "possible_cause": "HYPOTHESIS: ... or confirmed reason",\n'
            '  "diagnostic_steps": ["Step 1 description", "Step 2 description"],\n'
            '  "resolutions": ["Step 1 description [DOC_ID]", "Step 2 description [DOC_ID]"],\n'
            '  "sources": ["DOC_ID"],\n'
            '  "analyst_review_requirements": "string notes for human reviewer"\n'
            "}"
        )
        #system_prompt = (
        #     f"You are an Incident Resolution AI Assistant. Analyze the untrusted incident details against "
        #     f"the provided verified {evidence_label}.\n\n"
        #     "STRICT CITATION AND CONTENT RULES:\n"
        #     "1. Ground all steps strictly in the provided evidence documents.\n"
        #     "2. Root Cause: Provide a clear, thorough, and well-explained narrative detailing why and how the issue occurred based on the evidence. If the root cause is not definitively proven by the text, explicitly prefix it with 'HYPOTHESIS: ' followed by the detailed explanation.\n"
        #     "3. Diagnostic Steps: Detail the pre-checks, log reviews, and verification checks. Write each item as a complete sentence explaining what tool, table, or portal to inspect. Do NOT include bracketed document citations or references here.\n"
        #     "4. Resolutions: Detail the concrete execution, configuration, deactivation, remediation, or fix actions. Never return an empty list. Never output generic placeholders like 'Follow standard SOP', 'Refer to procedure', or 'Contact administrator'. Every resolution must be a specific, actionable, complete sentence extracted from the evidence. At the end of every individual resolution sentence, append the exact document/incident ID in brackets, e.g., 'Navigate to CIF User Management and deactivate each listed account [DOC_ID].'\n"
        #     "5. If a resolution step relies on multiple documents, append all citations: '[DOC_ID_1][DOC_ID_2]'.\n"
        #     "6. Never invent IDs. Only cite IDs present in <VERIFIED_EVIDENCE>.\n"
        #     "7. Output valid, raw JSON only matching this schema:\n"
        #     "{\n"
        #     '  "problem_summary": "string",\n'
        #     '  "possible_cause": "Thorough, well-explained root cause narrative",\n'
        #     '  "diagnostic_steps": ["Complete sentence describing diagnostic check 1.", "Complete sentence describing diagnostic check 2."],\n'
        #     '  "resolutions": ["Complete sentence describing actionable remediation step 1 [DOC_ID].", "Complete sentence describing actionable remediation step 2 [DOC_ID]."],\n'
        #     '  "sources": ["DOC_ID"],\n'
        #     '  "analyst_review_requirements": "string notes for human reviewer"\n'
        #     "}"
        # )
        

        user_content = (
            f"<UNTRUSTED_INCIDENT_DATA>\n{incident_body}\n</UNTRUSTED_INCIDENT_DATA>\n\n"
            f"<VERIFIED_EVIDENCE>\n{''.join(doc_contexts)}\n</VERIFIED_EVIDENCE>"
        )

        response = self.client.chat.completions.create(
            model=self.config.groq_model,
            messages=[
                {"role": "system", "content": system_prompt},
                {"role": "user", "content": user_content}
            ],
            response_format={"type": "json_object"},
            #max_completion_tokens=self.config.llm_output_reserved_tokens,
            temperature=0.0
        )

        raw_output = response.choices[0].message.content or "{}"
        parsed = json.loads(raw_output)

        # Validate sources list
        cited_sources = [s for s in parsed.get("sources", []) if s in valid_ids]
        parsed["sources"] = cited_sources
        parsed["source_type"] = source_type
        parsed["status"] = "GENERATED"
        return parsed

    @staticmethod
    def format_work_note(rec: dict[str, Any]) -> str:
        source_type = rec.get("source_type", "KB")

        # Converts [KB001] into KB links and [INC0012345] into Incident links
        def linkify_resolution_citations(text: str) -> str:
            def replace_tag(match: re.Match) -> str:
                full_id = match.group(1)
                # If reference is a historical incident number
                if full_id.upper().startswith("INC"):
                    return f'[<a href="/incident.do?sysparm_query=number={full_id}" target="_blank">{full_id}</a>]'
                
                # Otherwise treat as KB article (supports KB001 or KB001_Suffix)
                article_num = full_id.split("_")[0]
                return f'[<a href="/kb_view.do?sysparm_article={article_num}" target="_blank">{full_id}</a>]'

            return re.sub(r'\[([A-Za-z0-9_-]+)\]', replace_tag, text)

        diag_items = rec.get("diagnostic_steps", [])
        diag_lines = "<br>".join(f"- {step}" for step in diag_items) if diag_items else "- Review system logs"

        # Apply hyperlink conversion strictly to resolution steps
        res_items = rec.get("resolutions", [])
        res_lines = (
            "<br>".join(f"- {linkify_resolution_citations(step)}" for step in res_items)
            if res_items else "- Follow standard SOP"
        )

        source_header_note = (
            "Knowledge Base Articles" if source_type == "KB" 
            else "Historical Resolved Incidents (IT-Fin-SAP)"
        )

        # ServiceNow requires [code]...[/code] wrapper to parse <a> and <br> tags properly
        return (
            "[code]"
            f"<b>AI-Generated Recommendation</b><br><br>"
            f"<b>Root Cause:</b><br>{rec.get('possible_cause', 'Unknown')}<br><br>"
            f"<b>Diagnostic Steps:</b><br>{diag_lines}<br><br>"
            f"<b>Resolutions:</b><br>{res_lines}<br><br>"
            "<i>Generated by AI need human review before execution.</i>"
            "[/code]"
        )