import numpy as np
from sentence_transformers import SentenceTransformer

class EmbeddingManager:
    def __init__(self, model_name: str, max_tokens: int):
        self.model_name = model_name
        self.max_tokens = max_tokens
        self.model = SentenceTransformer(model_name)
        self.tokenizer = self.model.tokenizer

    def count_tokens(self, text: str) -> int:
        return len(self.tokenizer.encode(text, add_special_tokens=True))

    def validate_token_limit(self, text: str, source_identifier: str) -> int:
        count = self.count_tokens(text)
        if count > self.max_tokens:
            raise ValueError(
                f"Validation Error: '{source_identifier}' has {count} tokens, exceeding "
                f"the strict model limit of {self.max_tokens}. This POC enforces 1-document = 1-chunk "
                f"without truncation. Please reduce file size or reconfigure MAX_EMBEDDING_TOKENS."
            )
        return count

    def embed_normalized(self, texts: list[str]) -> np.ndarray:
        embeddings = self.model.encode(texts, convert_to_numpy=True, show_progress_bar=False)
        norms = np.linalg.norm(embeddings, axis=1, keepdims=True)
        norms[norms == 0] = 1e-12
        return (embeddings / norms).astype(np.float32)