import os
from dataclasses import dataclass
from dotenv import load_dotenv

load_dotenv()

@dataclass(frozen=True)
class AppConfig:
    sn_instance_url: str
    sn_username: str
    sn_password: str
    sn_assignment_groups: list[str]
    sn_new_state: str
    
    groq_api_key: str
    groq_base_url: str
    groq_model: str
    llm_context_budget_tokens: int
    llm_output_reserved_tokens: int
    
    embedding_model_name: str
    max_embedding_tokens: int
    
    dry_run: bool
    auto_post_saved_dry_runs: bool
    poll_interval_seconds: int
    poll_overlap_seconds: int
    page_size: int
    top_k: int
    similarity_threshold: float
    max_retries: int
    retry_base_backoff_seconds: float
    request_timeout_seconds: int

def load_config() -> AppConfig:
    groups_raw = os.getenv("SN_ASSIGNMENT_GROUPS", "Service Desk")
    assignment_groups = [g.strip() for g in groups_raw.split(",") if g.strip()]
    
    return AppConfig(
        sn_instance_url=os.getenv("SN_INSTANCE_URL", "").rstrip("/"),
        sn_username=os.getenv("SN_USERNAME", ""),
        sn_password=os.getenv("SN_PASSWORD", ""),
        sn_assignment_groups=assignment_groups,
        sn_new_state=os.getenv("SN_NEW_STATE", "1"),
        
        groq_api_key=os.getenv("GROQ_API_KEY", ""),
        groq_base_url=os.getenv("GROQ_BASE_URL", "https://api.groq.com/openai/v1"),
        groq_model=os.getenv("GROQ_MODEL", "llama-3.3-70b-versatile"),
        llm_context_budget_tokens=int(os.getenv("LLM_CONTEXT_BUDGET_TOKENS", "6000")),
        llm_output_reserved_tokens=int(os.getenv("LLM_OUTPUT_RESERVED_TOKENS", "1024")),
        
        embedding_model_name=os.getenv("EMBEDDING_MODEL_NAME", "BAAI/bge-small-en-v1.5"),
        max_embedding_tokens=int(os.getenv("MAX_EMBEDDING_TOKENS", "512")),
        
        dry_run=os.getenv("DRY_RUN", "true").lower() == "true",
        auto_post_saved_dry_runs=os.getenv("AUTO_POST_SAVED_DRY_RUNS", "false").lower() == "true",
        poll_interval_seconds=int(os.getenv("POLL_INTERVAL_SECONDS", "60")),
        poll_overlap_seconds=int(os.getenv("POLL_OVERLAP_SECONDS", "120")),
        page_size=int(os.getenv("PAGE_SIZE", "20")),
        top_k=int(os.getenv("TOP_K", "2")),
        similarity_threshold=float(os.getenv("SIMILARITY_THRESHOLD", "0.55")),
        max_retries=int(os.getenv("MAX_RETRIES", "3")),
        retry_base_backoff_seconds=float(os.getenv("RETRY_BASE_BACKOFF_SECONDS", "2.0")),
        request_timeout_seconds=int(os.getenv("REQUEST_TIMEOUT_SECONDS", "30")),
    )