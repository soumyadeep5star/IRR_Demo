from src.config import load_config
from src.embedder import EmbeddingManager
from src.servicenow_client import ServiceNowClient
from src.incident_vector_store import IncidentVectorStore

TARGET_GROUP = "IT-Fin-SAP"
# States 6 (Resolved) and 7 (Closed) in standard ServiceNow
TARGET_STATES = ["6", "7"]

def fetch_historical_incidents(client: ServiceNowClient, group_name: str) -> list[dict]:
    group_sys_id = client.resolve_group_sys_id(group_name)
    url = f"{client.base_url}/api/now/table/incident"
    
    query = (
        f"assignment_group={group_sys_id}^"
        f"stateIN{','.join(TARGET_STATES)}^"
        f"ORDERBYDESCsys_updated_on"
    )
    
    fields = (
        "sys_id,number,category,subcategory,assignment_group.name,"
        "short_description,description,work_notes,close_code,close_notes"
    )
    
    incidents = []
    offset = 0
    batch_size = 100

    print(f"Fetching historical incidents for group: '{group_name}' ({group_sys_id})...")
    while True:
        params = {
            "sysparm_query": query,
            "sysparm_limit": str(batch_size),
            "sysparm_offset": str(offset),
            "sysparm_fields": fields,
            "sysparm_display_value": "true"  # Resolves choice list and reference values directly
        }
        resp = client._execute_request("GET", url, params=params).json()
        results = resp.get("result", [])
        if not results:
            break

        for item in results:
            # Flatten assignment group display string if returned as object
            grp = item.get("assignment_group")
            grp_name = grp.get("display_value") if isinstance(grp, dict) else str(grp or "")

            incidents.append({
                "sys_id": item.get("sys_id", ""),
                "number": item.get("number", ""),
                "category": item.get("category", ""),
                "subcategory": item.get("subcategory", ""),
                "assignment_group": grp_name,
                "short_description": item.get("short_description", ""),
                "description": item.get("description", ""),
                "work_notes": item.get("work_notes", ""),
                "close_code": item.get("close_code", ""),
                "close_notes": item.get("close_notes", "")
            })

        print(f"Fetched {len(incidents)} incidents so far...")
        if len(results) < batch_size:
            break
        offset += batch_size

    return incidents

def main():
    config = load_config()
    sn_client = ServiceNowClient(config)
    embedder = EmbeddingManager(config.embedding_model_name, config.max_embedding_tokens)
    store = IncidentVectorStore(embedder)

    records = fetch_historical_incidents(sn_client, TARGET_GROUP)
    if not records:
        print("No historical incidents retrieved.")
        return

    store.build_from_records(records)

if __name__ == "__main__":
    main()